from flask import Flask
from flask_sqlalchemy import SQLAlchemy
app= Flask(__name__)
app.config ['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///feast.db'
db=SQLAlchemy(app)

class Customer(db.Model):
	id = db.Column(db.Integer,primary_key=True)
	username = db.Column(db.String(20),unique=True,nullable=False)
	name = db.Column(db.String(20),nullable=False)
	email = db.Column(db.String(120),nullable=False)
	address = db.Column(db.String(120),nullable=False)
	pincode = db.Column(db.Integer,nullable=False)
	PhoneNumber = db.Column(db.Integer,nullable=False)
	password = db.Column(db.String(20),nullable=False)

	def __repr__(self):
		 return f"Customer('{self.username}','{self.name}','{self.email}','{self.address}','{self.pincode}','{self.PhoneNumber}','{self.password}')"

class Vendor(db.Model):
	id = db.Column(db.Integer,primary_key=True)
	username = db.Column(db.String(20),unique=True,nullable=False)
	name = db.Column(db.String(20),nullable=False)
	email = db.Column(db.String(120),nullable=False)
	address = db.Column(db.String(120),nullable=False)
	pincode = db.Column(db.Integer,nullable=False)
	PhoneNumber = db.Column(db.Integer,nullable=False)
	password = db.Column(db.String(20),nullable=False)

	def __repr__(self):
		 return f"Vendor('{self.username}','{self.name}','{self.email}','{self.address}','{self.pincode}','{self.PhoneNumber}','{self.password}')"

class Service(db.Model):
	id = db.Column(db.Integer,primary_key=True)
	username = db.Column(db.String(20),unique=True,nullable=False)
	name = db.Column(db.String(20),nullable=False)
	email = db.Column(db.String(120),nullable=False)
	address = db.Column(db.String(120),nullable=False)
	pincode = db.Column(db.Integer,nullable=False)
	PhoneNumber = db.Column(db.Integer,nullable=False)
	password = db.Column(db.String(20),nullable=False)

	def __repr__(self):
		 return f"Service('{self.username}','{self.name}','{self.email}','{self.address}','{self.pincode}','{self.PhoneNumber}','{self.password}')"

db.create_all()