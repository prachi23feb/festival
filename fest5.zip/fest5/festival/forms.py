from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, SubmitField, BooleanField, IntegerField, RadioField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer


class RegistrationForm(FlaskForm):
	username=StringField('Username',
						validators=[DataRequired(), Length(min=2,max=20)])
	name=StringField('Name',validators=[DataRequired()])
	email=StringField('E-mail',
						validators=[DataRequired(), Email()])
	address=StringField('Address',validators=[DataRequired()])
	pincode=IntegerField('Pincode',validators=[DataRequired()])
	PhoneNumber=IntegerField('PhoneNumber',validators=[DataRequired()])
	example = RadioField('Type Of User', choices=[('0','Vendor'),('1','Customer'),('2','Service')])
	password=PasswordField('Password',validators=[DataRequired(), Length(min=8,max=30)])
	confirm_password=PasswordField('Confirm_Password',
						validators=[DataRequired(),EqualTo('password')])
	submit=SubmitField('Sign Up')



class LoginForm(FlaskForm):
	username=StringField('Username',
						validators=[DataRequired(), Length(min=2,max=20)])
	password=PasswordField('Password',
					validators=[DataRequired(), Length(min=8,max=30)])
	example = RadioField('Type Of User', choices=[('0','Vendor'),('1','Customer'),('2','Service')])
	remember=BooleanField('Remember Me')
	submit=SubmitField('Login')


class ForgetForm(FlaskForm):
	username=StringField('Username',
						validators=[DataRequired(), Length(min=2,max=20)])
	password=PasswordField('Password',
					validators=[DataRequired()])
	confirm_password=PasswordField('Confirm_Password',
						validators=[DataRequired(),EqualTo('password')])
	example = RadioField('Type Of User', choices=[('0','Vendor'),('1','Customer'),('2','Service')])
	submit=SubmitField('submit')
