from flask import Flask, render_template, flash,redirect, url_for, request
from festival.forms import RegistrationForm, LoginForm, ForgetForm
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager,login_user,current_user,logout_user
from flask_bcrypt import Bcrypt
import smtplib
import sqlite3
from flask_mail import Mail, Message
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer



app= Flask(__name__,template_folder='template')
app.config['Mail_SERVER']='smtp.googlemail.com'
app.config['Mail_PORT']=587
app.config['Mail_USE_TLS']=True
token='eyJhbGciOiJIUzUxMiIsImlhdCI6MTU5OTEyNzY1MywiZXhwIjoxNTk5MTI3NjgzfQ.eyJ1c2VyX2lkIjoxfQ.SNfr7ggQfeaHv5du_cWtZv5du9PxqCWuKjVCYMmxzzN4TtiB2581AYIkL1n6cVNscACAHOqrWo71AMdHXqK2Hg'
mail=Mail(app)



app.config['SECRET_KEY']='7025eeaa16af636e4028ddcc624e254b'
app.config ['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///feast.db'
db=SQLAlchemy(app)
login_manager = LoginManager(app)
bcrypt=Bcrypt(app)
from database import Customer,Vendor,Service
login_manager.login_message_category='info'

@app.route("/")

@app.route("/home")
def home():
	return render_template('home.html')

@app.route("/about")
def about():
	return render_template('about.html')

@app.route("/function")
def function():
	return render_template('function.html')

@app.route("/detail")
def detail():
	return render_template('detail.html')

@app.route("/register", methods=['GET','POST'])
def register():
	form=RegistrationForm()
	if form.validate_on_submit():
		if(form.example.data=='0'):
			ven = Vendor.query.filter_by(username=form.username.data).first()
			if ven:
				flash(f'Please use another username because it is already exist','danger')
				return redirect(url_for('register'))
			else:
				ven = Vendor(username = form.username.data,name = form.name.data,email = form.email.data,address = form.address.data,pincode = form.pincode.data,PhoneNumber = form.PhoneNumber.data,password =form.password.data)
				db.session.add(ven)
				try:
					db.session.commit()
					print("\n ")
					flash(f'Account created for {form.username.data}!','success')
					email=request.form.get("email")
					message="you have successfully registered!!"
					server = smtplib.SMTP('smtp.gmail.com:587')
					server.ehlo()
					server.starttls()
					server.login("abcfest2020@gmail.com","fest2020")
					server.sendmail("abcfest2020@gmail.com",email,message)
					return redirect(url_for('login'))
				except IntegrityError:
					flash(f'Please use another username because it is already exist','danger')

		if(form.example.data=='1'):
			cus = Customer.query.filter_by(username=form.username.data).first()
			if cus:
				flash(f'Please use another username because it is already exist','danger')
				return redirect(url_for('register'))
			else:
				cus = Customer(username = form.username.data,name = form.name.data,email = form.email.data,address = form.address.data,pincode = form.pincode.data,PhoneNumber = form.PhoneNumber.data,password =form.password.data)
				db.session.add(cus)
				try:
					db.session.commit()
					print("\n ")
					flash(f'Account created for {form.username.data}!','success')
					email=request.form.get("email")
					message="you have successfully registered!!"
					server = smtplib.SMTP('smtp.gmail.com:587')
					server.ehlo()
					server.starttls()
					server.login("abcfest2020@gmail.com","fest2020")
					server.sendmail("abcfest2020@gmail.com",email,message)
					return redirect(url_for('login'))
				except IntegrityError:
					flash(f'Please use another username because it is already exist','danger')
		if(form.example.data=='2'):
			ser = Service.query.filter_by(username=form.username.data).first()
			if ser:
				flash(f'Please use another username because it is already exist','danger')
				return redirect(url_for('register'))
			else:
				ser = Service(username = form.username.data,name = form.name.data,email = form.email.data,address = form.address.data,pincode = form.pincode.data,PhoneNumber = form.PhoneNumber.data,password =form.password.data)
				db.session.add(ser)
				try:
					db.session.commit()
					flash(f'Account created for {form.username.data}!','success')
					email=request.form.get("email")
					message="you have successfully registered!!"
					server = smtplib.SMTP('smtp.gmail.com:587')
					server.ehlo()
					server.starttls()
					server.login("abcfest2020@gmail.com","fest2020")
					server.sendmail("abcfest2020@gmail.com",email,message)
					return redirect(url_for('login'))
				except IntegrityError:
					flash(f'Please use another username because it is already exist','success')

	return render_template('register.html',title='Register',form=form)

@app.route("/login", methods=['GET','POST'])
def login():
	form=LoginForm()
	if form.validate_on_submit():
		if form.example.data=='0':
			ven = Vendor.query.filter_by(username=form.username.data).first()
			if ven:
				if ven.password == form.password.data:
					login_user(ven,remember=form.remember.data)
					flash(f'you are successfully login!!')
					return redirect(url_for("function"))
				else:
					flash(f'Login Unsuccess, Check username & password!!!','danger')
			else:
				flash(f'please check your information otherwise create new Account')
				return redirect(url_for("login"))
		if form.example.data=='1':
			cus = Customer.query.filter_by(username=form.username.data).first()
			if cus:
				if cus.password == form.password.data:
					login_user(cus,remember=form.remember.data)
					flash(f'you are successfully login!!')
					return redirect(url_for("home"))
				else:
					flash(f'Login Unsuccess, Check username & password!!!','danger')
			else:
				flash(f'please check your information otherwise create new Account')
				return redirect(url_for("login"))
		if form.example.data=='2':
			ser = Service.query.filter_by(username=form.username.data).first()
			if ser:
				if ser.password == form.password.data:
					login_user(ser,remember=form.remember.data)
					flash(f'you are successfully login!!')
					return redirect(url_for("detail"))
				else:
					flash(f'Login Unsuccess, Check username & password!!!','danger')
			else:
				flash(f'please check your information otherwise create new Account')
				return redirect(url_for("login"))

	return render_template('login.html',title='login',form=form)


@app.route("/forget", methods=['GET','POST'])
def forget():
	form=ForgetForm()
	if form.validate_on_submit():
		if form.example.data=='0':
			ven = Vendor.query.filter_by(username=form.username.data).first()
			if ven.username == form.username.data:
				ven.password = form.password.data
				db.session.commit()
				flash(f'your password is changed','success')
				return redirect(url_for("login"))
			else:
				flash(f'your Account is not available please create your Account','danger')
		if form.example.data=='1':
			cus = Customer.query.filter_by(username=form.username.data).first()
			if cus.username == form.username.data:
				cus.password = form.password.data
				db.session.commit()
				flash(f'your password is changed','success')
				return redirect(url_for("login"))
			else:
				flash(f'your Account is not available please create your Account','danger')
		if form.example.data=='2':
			ser = Service.query.filter_by(username=form.username.data).first()
			if ser.username == form.username.data:
				ser.password = form.password.data
				db.session.commit()
				flash(f'your password is changed')
				return redirect(url_for("login"))
			else:
				flash(f'your Account is not available please create your Account','danger')

	return render_template('forget.html',title='forget',form=form)

@app.route("/logout")
def logout():
	logout_user()
	return redirect(url_for("home"))


if __name__=='__main__':
	app.run(debug=True)
