from __main__ import db, login_manager
from flask_login import UserMixin


@login_manager.user_loader
def load_user(cus_id):
	return Customer.query.get(int(cus_id))

@login_manager.user_loader
def load_user(ven_id):
	return Vendor.query.get(int(ven_id))

@login_manager.user_loader
def load_user(ser_id):
	return Service.query.get(int(ser_id))

class Customer(db.Model,UserMixin):
	id = db.Column(db.Integer,primary_key=True)
	username = db.Column(db.String(20),unique=True,nullable=False)
	name = db.Column(db.String(20),nullable=False)
	email = db.Column(db.String(120),nullable=False)
	address = db.Column(db.String(120),nullable=False)
	pincode = db.Column(db.Integer,nullable=False)
	PhoneNumber = db.Column(db.Integer,nullable=False)
	password = db.Column(db.String(20),unique=True,nullable=False)

	def __repr__(self):
		 return f"Customer('{self.username}','{self.name}','{self.email}','{self.address}','{self.pincode}','{self.PhoneNumber}','{self.password}')"

class Vendor(db.Model,UserMixin):
	id = db.Column(db.Integer,primary_key=True)
	username = db.Column(db.String(20),unique=True,nullable=False)
	name = db.Column(db.String(20),nullable=False)
	email = db.Column(db.String(120),nullable=False)
	address = db.Column(db.String(120),nullable=False)
	pincode = db.Column(db.Integer,nullable=False)
	PhoneNumber = db.Column(db.Integer,nullable=False)
	password = db.Column(db.String(20),unique=True,nullable=False)

	def __repr__(self):
		 return f"Vendor('{self.username}','{self.name}','{self.email}','{self.address}','{self.pincode}','{self.PhoneNumber}','{self.password}')"

class Service(db.Model,UserMixin):
	id = db.Column(db.Integer,primary_key=True)
	username = db.Column(db.String(20),unique=True,nullable=False)
	name = db.Column(db.String(20),nullable=False)
	email = db.Column(db.String(120),nullable=False)
	address = db.Column(db.String(120),nullable=False)
	pincode = db.Column(db.Integer,nullable=False)
	PhoneNumber = db.Column(db.Integer,nullable=False)
	password = db.Column(db.String(20),unique=True,nullable=False)

	def __repr__(self):
		 return f"Service('{self.username}','{self.name}','{self.email}','{self.address}','{self.pincode}','{self.PhoneNumber}','{self.password}')"

